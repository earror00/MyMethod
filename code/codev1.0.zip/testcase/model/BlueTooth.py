# coding=utf-8

import os
from runner.application.testmodelbase import Model
from runner.common.runnerlog import RunnerLog as Logger

package = "com.**.**"  # 启动包名
activity = "com.**.*activity"  # 启动活动名称
'''
断言采用 
self.assertion.assertTrue(expr, msg=None)
self.assertion.assertEqual(first, second, msg=None):
'''

package1 = "com.android.settings"  # 启动包名
activity1 = "com.android.settings.Settings"  # 启动活动名称
settings_toolbar = 'com.android.settings:id/toolbar_title'    #
settings_searchBox = 'com.android.settings:id/animated_hint'
blueTooth_bar = 'com.coloros.wirelesssettings:id/toolbar'
Bluetooth = 'Bluetooth'
blueTooth_switchBox = 'com.coloros.wirelesssettings:id/switchWidget'
blueTooth_nameID = 'com.coloros.wirelesssettings:id/assignment'

class BlueTooth(Model):
    """
    model 模板，开发脚本使用
    """

    def __init__(self, case=None, order=None):
        super(BlueTooth, self).__init__(case, order)
        self.current_dir = os.path.dirname(__file__)
        self.resource_path = os.path.join(os.path.dirname(self.current_dir),'resources')

    def openBlueTooth(self):
        """
        open BlueTooth
        """
        Logger.info("open BlueTooth")
        self.device.start_activity(package, activity)
        
    def closeBlueTooth(self):
        """
        close BlueTooth
        """
        Logger.info("close BlueTooth")
        self.device.close_app(package)

    def openSetting(self):
        """
        open Setting main View
        """     
        self.device.start_activity(package1, activity1)
        self.device.sleep(2)
        if self.device.find_element_by_id(settings_toolbar,ifexist=True) and \
        self.device.find_element_by_id(settings_searchBox,ifexist=True):
            Logger.info("成功进入设置")
        else:
            raise AssertionError,"打开设置失败！"
    
    def openAndCloseBlueTooth1(self):
        """
        open bluetooth
        """   
        self.device.find_element_by_name(Bluetooth).click()
        self.device.sleep(2)
        if self.device.find_element_by_id(blueTooth_bar,ifexist=True) and \
        self.device.find_element_by_id(blueTooth_switchBox,ifexist=True):
            Logger.info("进入蓝牙设置界面成功")
        else:
            raise AssertionError,"计入蓝牙设置界面失败"
        if self.device.find_element_by_id(blueTooth_switchBox).isChecked():
            Logger.info("蓝牙处于打开状态，进行关闭操作")
            self.device.sleep(1)
            self.device.find_element_by_id(blueTooth_switchBox).click()
            self.device.sleep(2)
            if not self.device.find_element_by_id(blueTooth_nameID,ifexist=True) and \
            not self.device.find_element_by_id(blueTooth_switchBox).isChecked():
                Logger.info("蓝牙关闭成功")
            else:
                raise AssertionError,"蓝牙关闭失败"
        else:
            Logger.info("蓝牙处于关闭状态，进行开启操作") 
            self.device.sleep(1)
            self.device.find_element_by_id(blueTooth_switchBox).click()  
            self.device.sleep(2)
            if self.device.find_element_by_id(blueTooth_nameID,ifexist=True) and \
            self.device.find_element_by_id(blueTooth_switchBox).isChecked():
                Logger.info("蓝牙开启成功")
            else:
                raise AssertionError,"蓝牙开启失败"    
        
        
        
        
        
        



