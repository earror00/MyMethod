# coding=utf-8
'''
    基于log生成测试
'''

import os
import time
from runner.application.builder import TestBuilder
from runner.common.identifykey import IdentifyKey
import json
from runner.common.runnerlog import RunnerLog as Logger
from collections import OrderedDict 

current_path = os.getcwd()  # 当前文件所在目录
count = 10  # 单个case测试次数
data_path = os.path.join(current_path, 'data')

DATA_FILE = "testData"


class Cases():
    def __init__(self, name, cycle=None):
        self.caseName = name;
        self.cycle = cycle
        self.commands = []
        self.result = False
        
    @staticmethod
    def strToCase(name,str):
        case = Cases(name,str['Cycle'])
        case.result = str['Result']
        case.commands = str['Commands']
        return case
    
    def clear(self):
        self.result = False
        self.commands = []
    
    def addCommand(self, command):
        self.commands.append(command)
    
    def getResult(self,line):
            result = line[(line.find('"result": ') + 10):(line.find('"result": ') + 11)]
            if result == '0':
                return True;
            return False
            
    def setTestResult(self, result):
        
        if IdentifyKey._erroresult_prefix in result:
            self.result = False
        elif IdentifyKey._casereuslt_prefix in result and self.getResult(result):
            self.result = True
    
    def __repr__(self):
        return self.__str__()
    
    def __str__(self):
        commandsss=''
        for command in self.commands:
            if type(command) == type({}):
                command = str(command)+','
            commandsss+=command.replace('\n',',')
        commandsss = commandsss[0:-1]
        return '{"Count":%d, "Result":"%s", "Commands":[%s]}'%(self.cycle, self.result, commandsss)

def find_new():
    log_path = os.path.join(current_path, 'log')
    if os.path.exists(log_path):
        for dirpath, dirname, files in os.walk(log_path):
            newly = None
            for filename in files:
                tmp = filename[8:-4]
                current = time.strptime(tmp, "%Y%m%d-%H%M%S")
                time.time()
                if newly == None:
                    newly = current
                elif time.mktime(current) > time.mktime(newly):
                    newly = current
            file_name = time.strftime('%Y%m%d-%H%M%S', newly)
            #file_name = "20180605-173500"
            filepath = os.path.join(dirpath, "runntime"+file_name+".log")
            return filepath
        
def make_data(allCases, data):
    caseToStr = generateTestData(allCases, data)
    data_file = open(DATA_FILE, 'w+')
    data_file.write(caseToStr.replace("'", "\"").replace('False', 'false').replace('True', 'true').replace('None','null'))
    data_file.close()  


def checkResult(line):
    if IdentifyKey._casereuslt_prefix in line:
        return IdentifyKey._casereuslt_prefix
    elif IdentifyKey._erroresult_prefix in line:
        return IdentifyKey._erroresult_prefix
    return None
                   
                
def find_case_name(path,allCases):
    caseName = None
    flag = False;
    allCaseName = allCases.keys()
    casesInFile = []
    currentCase = None
    if os.path.exists(path):
        f = open(path, 'r')
        for line in f.readlines():
            if line.endswith('*****start test*****\n'): 
                flag = True
                continue
            
            if flag and "test_" in line:
                data = line[(line.find("test_")):]
                items = data.split(" ")
                caseName = items[1][1:-2]+"."+items[0]
                flag = False
                
                if caseName in allCaseName and caseName not in casesInFile:
                    currentCase = allCases.get(caseName)
                    casesInFile.append(caseName)
                elif caseName  in casesInFile:
                    currentCase = None
                continue
            
            if currentCase == None:
                continue
            if 'Yep Http post data' in line:
                data = line[(line.find("Yep Http post data") + 19):]
                currentCase.addCommand(data)
            elif checkResult(line):
                currentCase.setTestResult(line)
            
                
        f.close()
    return caseName

def find_case_debug_name(path,allCases):
    caseName = None
    flag = False;
    allCaseName = allCases.keys()
    casesInFile = []
    currentCase = None
    if os.path.exists(path):
        f = open(path, 'r')
        for line in f.readlines():
            if line.endswith('*****start test*****\n'): 
                flag = True
                continue
            
            if flag and "test_" in line:
                data = line[(line.find("test_")):]
                items = data.split(" ")
                caseName = items[1][1:-2]+"."+items[0]
                flag = False
                
                if caseName in allCaseName and caseName not in casesInFile:
                    currentCase = allCases.get(caseName)
                    currentCase.clear()
                    casesInFile.append(caseName)
                elif caseName  in casesInFile:
                    currentCase = None
                continue
            
            if currentCase == None:
                continue
            if 'Yep Http post data' in line:
                data = line[(line.find("Yep Http post data") + 19):]
                currentCase.addCommand(data)
            elif checkResult(line):
                currentCase.setTestResult(line)
            
                
        f.close()
    return caseName

def orderDictToStr(order_cases):
    result = '{'
    for k,v in order_cases.items():
        result += "'%s':%s,"%(k,v)
    result +="}"
    return result.replace(",}", "}")

def generateTestData(order_cases, data):
    builder = TestBuilder.getBuilder(data)
    cycle = builder.getCycle_offline()
    endTime = builder.getLTREndTime_offline()
    result = '{"projectDef":{'+'"cycle":'+str(cycle)+',"endTime":"'+endTime+'"},"actionDef":{'
    for k,v in order_cases.items():
        result += "'%s':%s,"%(k,v)
    result +="}}"
    return result.replace(",}", "}")
    
def testCaseInit(data):
    builder = TestBuilder.getBuilder(data)
    tests = builder.getTests(mode = 1)
    cases_order = OrderedDict()

    for (k, v) in tests:
        case = Cases(k,v)
        cases_order[k] = case
    return cases_order
    
    
def loadDataNormal(data):
    Logger.info('start load testData'.center(50,"*"))
    allCases = testCaseInit(data)
    getData(allCases, data)
    Logger.info('finish load testData'.center(50,"*"))
    
def loadDataDebug(data):
    Logger.info('start load debug testData'.center(50,"*"))
    casesInTestData = None
    global false,true,null
    false = False
    true = True
    null = None
    if os.path.exists(DATA_FILE):
        f = open("testData", 'r')
        for line in f.readlines():
            casesInTestData = eval(line)
            break
        f.close()
    if casesInTestData != None:
        for (k,v) in casesInTestData.items():
            cases = Cases.strToCase(k,v)
            casesInTestData[k] = cases
    allCases = testCaseInit(data)
    for (k,v) in allCases.items():
        if k in casesInTestData.keys():
            casesInTestData[k].cycle = v.cycle
            allCases[k] = casesInTestData[k]
    nearest_file = find_new()
    if nearest_file == None:
        raise  Exception("get log file failure， please run case first")
    find_case_debug_name(nearest_file, allCases)
    make_data(allCases, data)
    Logger.info('finish load debug testData'.center(50,"*"))
    

        
        

def getData(allCases, data):
    nearest_file = find_new()
    if nearest_file == None:
        raise  Exception("get log file failure， please run case first")
    find_case_name(nearest_file, allCases)
    make_data(allCases, data)    



if __name__ == "__main__":
    #getData()
    data = { 
        'plan': "./plan",
        'project':"./project"
    }
    testCaseInit(data)


