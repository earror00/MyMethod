# coding=utf-8

import os
from runner.application.testmodelbase import Model
from runner.common.runnerlog import RunnerLog as Logger
from runner.common.assertion import Assertion

package = "com.**.**"  # 启动包名
activity = "com.**.*activity"  # 启动活动名称
'''
断言采用 
self.assertion.assertTrue(expr, msg=None)
self.assertion.assertEqual(first, second, msg=None):
'''

settings_toolbar = 'com.android.settings:id/toolbar_title'    #
settings_searchBox = 'com.android.settings:id/animated_hint'
Additional_settings = 'Additional settings'
reset = 'Back up and reset'
factory_reset = 'Erase all data (factory reset)'
Erase_all_data = 'Erase all data'
Erase_data = 'Erase data'


class Common(Model):
    """
    model 模板，开发脚本使用
    """

    def __init__(self, case=None, order=None):
        super(Common, self).__init__(case, order)
        self.current_dir = os.path.dirname(__file__)
        self.resource_path = os.path.join(os.path.dirname(self.current_dir),'resources')

    def openCommon(self):
        """
        open Common
        """
        Logger.info("open Common")
        self.device.start_activity(package, activity)
        
    def closeCommon(self):
        """
        close Common
        """
        Logger.info("close Common")
        self.device.close_app(package)

    def wakeupDevice(self):
        Logger.info("wakeup device")
    
        self.device.wake()
        self.device.sleep(2)
        if self.device.find_element_by_id('com.android.systemui:id/clock_time_minutes_txt',ifexist=True):
            Logger.info("手机唤醒成功")
            self.device.swipe(550,2100,550,400)
        else:
            raise AssertionError,"手机唤醒失败"
    
    
    def wakeupAndSleepDevice(self):
        Logger.info("wakeup and sleep device")
        
        self.device.wake()
        self.device.sleep(2)
        if self.device.find_element_by_id('com.android.systemui:id/clock_time_minutes_txt',ifexist=True):
            Logger.info("手机唤醒成功")
        else:
            raise AssertionError,"手机唤醒失败"
        self.device.lock()
        self.device.sleep(3)
     
#     def rebootDevice(self):
#         Logger.info("reboot device")
#         
#         adb_command = 'reboot'
#         self.device.wake()
#         self.device.do_adb(adb_command)
#         self.device.sleep(2)
#         adb_command1 = 'adb devices | findstr /e "device"'
#         if len(str(os.system(adb_command1))) == 0:
#             Logger.info("手机重启中")
#             self.device.sleep(40)
#             self.device.wake()
#             self.device.sleep(2)
#             if self.device.find_element_by_id('com.android.systemui:id/clock_time_minutes_txt',ifexist=True):
#                 Logger.info("手机重启成功")
#             else:
#                 raise AssertionError,"手机重启失败，未成功开机"
#         else:
#             raise AssertionError,"手机重启失败，关机失败"
    def rebootDevice(self):
        Logger.info("reboot device")   
        
        adb_command = 'reboot'
        self.device.wake()
        self.device.do_adb(adb_command)
        self.device.sleep(2)

    def resetDevice(self):
        Logger.info("reset device")
        
        adb_command = 'shell am start -n com.android.settings/com.android.settings.Settings'
        self.device.do_adb(adb_command)
        self.device.sleep(2)
        if self.device.find_element_by_id(settings_toolbar,ifexist=True) and \
        self.device.find_element_by_id(settings_searchBox,ifexist=True):
            Logger.info("成功进入设置")
        else:
            raise AssertionError,"打开设置失败！"
        
        for i in range(10):
            if self.device.find_element_by_name(Additional_settings,ifexist=True):
                self.device.find_element_by_name(Additional_settings).click()
                self.device.sleep(2)
                break
            else:
                self.device.pageUp()
                self.device.sleep(2)
                continue
        
        for i in range(5):
            if self.device.find_element_by_name(reset,ifexist=True):
                self.device.find_element_by_name(reset).click()
                self.device.sleep(2)
                break
            else:
                self.device.pageUp()
                self.device.sleep(2)
                continue
        self.device.find_element_by_name(factory_reset).click()
        self.device.sleep(2)
        self.device.find_element_by_name(Erase_all_data).click()
        self.device.sleep(2)
        self.device.find_element_by_name(Erase_data).click()
        self.device.sleep(2)
        self.device.find_element_by_name(Erase_data).click()
        
        
             