# coding=utf-8

import os
from runner.application.testcasebase import TestCaseBase
from runner.common.runnerlog import RunnerLog as Logger
from runner.application.device import DeviceManage
from testcase.model.wifi import Wifi
from testcase.model.Common import Common

'''
    :caseID 
    :前提条件  无
    :测试步骤 1.打开wifi
            2.关闭wifi
    :预期结果 1.wifi成功打开
            2.wifi成功关闭
'''
class MyTest(TestCaseBase):

    @classmethod
    def setUpClass(cls):
        ''' 测试case模块初始化, 作用于整个测试周期'''
        cls.current_dir = os.path.dirname(__file__)
        cls.resource_path = os.path.join(os.path.dirname(os.path.dirname(cls.current_dir)),'resources')
        super(MyTest, cls).setUpClass()
        try:
            '''模块初始化'''
            
        except Exception, e:
            Logger.error('MyTest module init failure: ' + str(e))
            
            
    @classmethod
    def tearDownClass(cls):
        super(MyTest, cls).tearDownClass()
        try:
            '''模块资源释放'''
            
        except Exception, e:
            Logger.error('MyTest module clear resource failure: ' + str(e))
    
    def setUp(self):
        ''' 测试case初始化，作用于单个测试方法'''
        super(MyTest, self).setUp()
        self.Wifi = Wifi(self)# 初始化model
        self.Common = Common(self)
        self.Common.wakeup()

    def tearDown(self):
        super(MyTest, self).tearDown()

    def test_Wifi_stress(self):
        
        self.Wifi.openWifiView()
        self.Wifi.openWifi()
        self.device.sleep(2)
        self.Wifi.closeWifi()
        
        pass
