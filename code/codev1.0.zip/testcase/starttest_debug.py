# coding=utf-8
"""
Created on 2015年11月23日

@author: thomas.ning
"""
import sys, string
from runner.application.application import Application
from makeTestData import loadDataDebug



class CommandOptions(object):
    """
    command option used by params setup
    """

    def __init__(self, argv):

        self.data = { 
                     'plan': "./plan",
                     'project':"./project"
                     }
        if len(argv) > 1:
            for arg in argv[1:]:
                if string.find(arg, '--plan=') == 0:
                    value = arg[len('--plan='):]
                    if self.data['plan'] is None:
                        self.data['plan'] = value
                    else:
                        raise ValueError, 'Invalid options...'
                elif string.find(arg, '--project=') == 0:
                    value = arg[len('--project='):]
                    self.data['project'] = value
                else:
                    raise ValueError, 'Invalid options...'
def main(argv):
    options = CommandOptions(argv)
    Application(options.data, mode=2).run()
    loadDataDebug(options.data)

if __name__ == '__main__':
    main(sys.argv)