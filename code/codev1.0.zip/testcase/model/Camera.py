# coding=utf-8

import os
from runner.application.testmodelbase import Model
from runner.common.runnerlog import RunnerLog as Logger

package = "com.oppo.camera"  # 启动包名
activity = "com.oppo.camera.Camera"  # 启动活动名称
'''
断言采用 
self.assertion.assertTrue(expr, msg=None)
self.assertion.assertEqual(first, second, msg=None):
'''


class Camera(Model):
    """
    model 模板，开发脚本使用
    """

    def __init__(self, case=None, order=None):
        super(Camera, self).__init__(case, order)
        self.current_dir = os.path.dirname(__file__)
        self.resource_path = os.path.join(os.path.dirname(self.current_dir),'resources')

    def openCamera(self):
        """
        open Camera
        """
        Logger.info("open Camera")
        self.device.start_activity(package, activity)
        
    def closeCamera(self):
        """
        close Camera
        """
        Logger.info("close Camera")
        self.device.close_app(package)

    def isFirstInto(self):
        """
        is first into camera
        """
        if self.device.find_element_by_name('OK',ifexist=True):
            self.device.find_element_by_name('OK').click()
        if self.device.find_element_by_name('Allow',ifexist=True):
            self.device.find_element_by_name('Allow').click()
        if self.device.find_element_by_name('Allow',ifexist=True):
            self.device.find_element_by_name('Allow').click()
        if self.device.find_element_by_name('Allow',ifexist=True):
            self.device.find_element_by_name('Allow').click()    
        
    def isCameraOpened(self):
        Logger.info("判断相机是否已打开")
        if self.device.find_element_by_id('com.oppo.camera:id/shutter_button',ifexist=True):
            Logger.info("相机已打开")
            self.device.sleep(30)
        else:
            raise AssertionError,"相机未打开"    
        
#     def isCameraClosed(self):
#         Logger.info("判断相机是否关闭")
#         command = 'shell dumpsys ps | findstr ' + package
#         result = self.device.do_adb(command)
#         print(result)
#         if len(result) == 0:
#             Logger.info("相机关闭成功")
#         else:
#             raise AssertionError,"相机关闭失败"
      
    def isCameraClosed(self):
        Logger.info("判断相机是否关闭") 
        if self.device.find_element_by_id('com.oppo.launcher:id/page_indicator',ifexist=True):
            Logger.info("退出相机成功")
        else:
            raise AssertionError,"退出相机失败"
            
        


