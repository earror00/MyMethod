# coding=utf-8

import os
from runner.application.testmodelbase import Model
from runner.common.runnerlog import RunnerLog as Logger

package = "com.android.settings"  # 启动包名
activity = "com.android.settings.Settings"  # 启动活动名称
'''
断言采用 
self.assertion.assertTrue(expr, msg=None)
self.assertion.assertEqual(first, second, msg=None):
'''

# 各类ID/name等控件属性
wifiName_name= 'Wi-Fi'
wifiToolBar_ID = 'com.coloros.wirelesssettings:id/toolbar'
wifiSwitch_ID = 'com.coloros.wirelesssettings:id/switchWidget'
wifiNetWorks_name = 'WI-FI NETWORKS'
wifiRefresh_name= 'Refresh'


class Wifi(Model):
    """
    model 模板，开发脚本使用
    """

    def __init__(self, case=None, order=None):
        super(Wifi, self).__init__(case, order)
        self.current_dir = os.path.dirname(__file__)
        self.resource_path = os.path.join(os.path.dirname(self.current_dir),'resources')

    def openWifiView(self):
        """
        open Wifi
        """
        Logger.info("open Wifi")
        self.device.start_activity(package, activity)   #仅通过其打开设置主界面，直接打开wifi设置界面出现界面不显示的问题
        
    def closeWifi(self):
        """
        close Wifi
        """
        Logger.info("close Wifi")
        self.device.close_app(package)  
        
    
    
    def openWifi(self):
        
        self.device.sleep(2)
        if self.device.find_element_by_name(wifiName_name,ifexist=True):
            self.device.find_element_by_name(wifiName_name).click()
            self.device.sleep(2)
        if self.device.find_element_by_id(wifiToolBar_ID,ifexist=True) and \
        self.device.find_element_by_name(wifiName_name,ifexist=True):   
            Logger.info("成功计入wifi界面")
        else:
            raise AssertionError,"进入wifi界面失败"
        if not self.device.find_element_by_id(wifiSwitch_ID).isChecked():
            self.device.find_element_by_id(wifiSwitch_ID).click()
            if self.device.find_element_by_name(wifiNetWorks_name,ifexist=True) and self.device.find_element_by_name(wifiRefresh_name,ifexist=True):
                Logger.info("开启wifi成功")
                self.device.sleep(5)
            else:
                raise AssertionError,"开启wifi失败"
        else:
            raise AssertionError,"上一次关闭wifi失败"
     
    
    def closewifi(self):
        '''
        close wifi
        '''  
        if self.device.find_element_by_name(wifiName_name,ifexist=True):
            self.device.find_element_by_name(wifiName_name).click()
            self.device.sleep(2)
        if self.device.find_element_by_id(wifiToolBar_ID,ifexist=True) and \
        self.device.find_element_by_name(wifiName_name,ifexist=True):   
            Logger.info("成功计入wifi界面")
        else:
            raise AssertionError,"进入wifi界面失败" 
        if self.device.find_element_by_id(wifiSwitch_ID).isChecked():
            self.device.find_element_by_id(wifiSwitch_ID).click()
            if not self.device.find_element_by_name(wifiNetWorks_name,ifexist=True) and not self.device.find_element_by_name(wifiRefresh_name,ifexist=True):
                Logger.info("关闭wifi成功")
                self.device.sleep(5)
            else:
                raise AssertionError,"关闭wifi失败"
        else:
            raise AssertionError,"上一次开启wifi失败"
