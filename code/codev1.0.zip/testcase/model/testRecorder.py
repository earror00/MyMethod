# coding=utf-8
"""
@author: thomas.ning
说明：测试录制脚本调试使用，完成model中具体方法的实现调试
"""
from runner.application.testdriver import TestDriver
from runner.common.runnerlog import RunnerLog as Logger
import unittest,os


class TestRecorder(unittest.TestCase):
			
	def setUp(self):
		self.current_dir = os.path.dirname(__file__)
		self.resource_path = os.path.join(os.path.dirname(self.current_dir),'resources')
		# 初始化设备
		self.device = TestDriver.connect_device()

	def tearDown(self):
		# 释放设备
		self.device.quit()
		
	def test_recorder(self):
		# 具体代码录制区域
		Logger.info("test_recorder")
		
		print(os.system('adb devices | findstr /e "device"'))
			
		
		
		
if __name__ == '__main__':
	unittest.main()