# coding=utf-8
"""
Created on 2018年05月15日

@author: lxs
"""
import sys, string, os
from easyuiautomator.driver.executor.adb_offline import AdbOffline
from runner.common.cofingparser import ConfigParser





class CommandOptions(object):
    """
    command option used by params setup
    """

    def __init__(self, argv):

        self.data = { 
                     'plan': "./plan",
                     'project':"./project"
                     }
        if len(argv) > 1:
            for arg in argv[1:]:
                if string.find(arg, '--plan=') == 0:
                    value = arg[len('--plan='):]
                    if self.data['plan'] is None:
                        self.data['plan'] = value
                    else:
                        raise ValueError, 'Invalid options...'
                elif string.find(arg, '--project=') == 0:
                    value = arg[len('--project='):]
                    self.data['project'] = value
                else:
                    raise ValueError, 'Invalid options...'
    def getTests(self):
        """Return the test case list specified by plan file """
        tests = ConfigParser.readTests(self.plan)
        return tests
def main(argv):
    options = CommandOptions(argv)
    _adb = AdbOffline(options=options.data)
    _adb.startTestOffline();

if __name__ == '__main__':
    main(sys.argv)