# coding=utf-8

import os
from runner.application.testcasebase import TestCaseBase
from runner.common.runnerlog import RunnerLog as Logger
from testcase.model.Camera import Camera


'''
    :caseID 
    :前提条件  无
    :测试步骤 1.打开相机,在主界面停留30S
            2.关闭相机
    :预期结果 1.相机成功打开
            2.相机成功关闭
'''


class CameraTest(TestCaseBase):

    @classmethod
    def setUpClass(cls):
        ''' 测试case模块初始化, 作用于整个测试周期'''
        cls.current_dir = os.path.dirname(__file__)
        cls.resource_path = os.path.join(os.path.dirname(os.path.dirname(cls.current_dir)),'resources')
        super(CameraTest, cls).setUpClass()
        try:
            '''模块初始化'''
            
        except Exception, e:
            Logger.error('CameraTest module init failure: ' + str(e))
            
            
    @classmethod
    def tearDownClass(cls):
        super(CameraTest, cls).tearDownClass()
        try:
            '''模块资源释放'''
            
        except Exception, e:
            Logger.error('CameraTest module clear resource failure: ' + str(e))
    
    def setUp(self):
        ''' 测试case初始化，作用于单个测试方法'''
        super(CameraTest, self).setUp()
          # 初始化model
        self.Camera = Camera(self)

    def tearDown(self):
        super(CameraTest, self).tearDown()

    def test_Camera_stree(self):
        
        self.Camera.openCamera()
        self.Camera.isFirstInto()
        self.Camera.isCameraOpened()
        self.Camera.closeCamera()
        self.Camera.isCameraClosed()
        
        
        pass
