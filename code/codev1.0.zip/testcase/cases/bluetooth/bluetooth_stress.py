# coding=utf-8

import os
from runner.application.testcasebase import TestCaseBase
from runner.common.runnerlog import RunnerLog as Logger
from testcase.model.BlueTooth import BlueTooth
from testcase.model.Common import Common

'''
    :caseID 
    :前提条件  无
    :测试步骤 1.打开蓝牙
            2.关闭蓝牙
    :预期结果 1.蓝牙成功打开
            2.蓝牙成功关闭
'''


class BluetoothTest(TestCaseBase):

    @classmethod
    def setUpClass(cls):
        ''' 测试case模块初始化, 作用于整个测试周期'''
        cls.current_dir = os.path.dirname(__file__)
        cls.resource_path = os.path.join(os.path.dirname(os.path.dirname(cls.current_dir)),'resources')
        super(BluetoothTest, cls).setUpClass()
        try:
            '''模块初始化'''
            
        except Exception as e:
            Logger.error('BluetoothTest module init failure: ' + str(e))
            
            
    @classmethod
    def tearDownClass(cls):
        super(BluetoothTest, cls).tearDownClass()
        try:
            '''模块资源释放'''
            
        except Exception as e:
            Logger.error('BluetoothTest module clear resource failure: ' + str(e))
    
    def setUp(self):
        ''' 测试case初始化，作用于单个测试方法'''
        super(BluetoothTest, self).setUp()
        self.BlueTooth =  BlueTooth(self)  # 初始化model
        self.Common = Common(self)
        
        self.Common.wakeupDevice()

    def tearDown(self):
        super(BluetoothTest, self).tearDown()

    def test_Bluetooth_stress(self):
        
        self.BlueTooth.openSetting()
        self.BlueTooth.openAndCloseBlueTooth1()
        
        pass
