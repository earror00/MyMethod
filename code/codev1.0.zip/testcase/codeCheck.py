#coding=utf-8
'''
Created on 2017年9月15日

@author: fengbo
'''

import  os


class ErrorCode:    
    ErrorUnknow = '未知的错误'
    ErrorUnknowType ='未知的测试类型'
    ErrorCMNamed = '存在Case包名与Model层命名不一致'
    ErrorCFirstUpper = '存在首字母未小写命名的Case名'
    ErrorMFirstUpper = '存在首字母未小写命名的Model'
    ErrorLogFolder = '存在未删除log目录'
    ErrorReportFolder = '存在未删除report目录'
    ErrorCheckPoint = '存在缺少check点的Case'
    


class CodeCheck:

    def __init__(self):
        self.ppath =os.path.abspath(os.path.dirname(__file__)+os.path.sep+"..")
        self.path = os.path.join(self.ppath,"testcase")   #testcase目录
        self.modelPath = os.path.join(self.path,"model")   #model目录
        self.casesPath = os.path.join(self.path,"cases")   #cases目录
        self.modelFiles = []            
        self.result = []
        self.uploadsResult = []

    '''
    @summary: 步骤——工程命名相关检查
    '''    
    def step_projectNamed(self):
        
        self.check_name()
        
        for dirname in os.listdir(self.path):
            dirpath = os.path.join(self.path,dirname)
            if os.path.isdir(dirpath):                
                self.check_directory(dirname,dirpath)
                if dirname == "model":
                    if len(self.modelFiles)==0:
                        self._getModelFiles()
                    self.check_model(dirpath) 
                elif dirname == "cases":
                    if len(self.modelFiles)==0:
                        self._getModelFiles()
                    self.check_cases( dirpath)                
#                 elif dirname == "resources":
#                     pass

    '''
    @summary: 步骤——文件内容检查
    '''    
    def step_fileChecked(self):
        filesList = []
        for root, dirs, files in os.walk(self.casesPath):
            for file in  files:
                cp = os.path.join(root,file)
                if "__init__" not in file and file.split(".")[-1]!="pyc":
                    filesList.append(cp)
        
        if filesList:
            for f in filesList:
                casename = f.split(os.path.sep)[-1].split(".")[-2]
                case = open(f)                 
                content = self._caseFileFilter(case,casename)
                self._caseContentCheck(content)
                case.close()
    
    '''
    @summary: case中check点检测
    @param casefile:case文件路径
    @param casename:case文件名称
    '''
    def _caseFileFilter(self,casefile,casename):
        rlist = []
        tar = 0
        for line in casefile:
            if not line or not len(line.strip()):
                continue
            if casename in line and "def test" in line:
                tar = 1
                rlist.append(line.strip())
            elif tar == 1:
                if casename not in line and "def test" in line:
                    break
                rlist.append(line.strip())                
        tar = 0
        return rlist
    
    def _caseContentCheck(self,content):
        if content:
            if "check" not in content[-1]:                
                self.deal_result(ErrorCode.ErrorCheckPoint,content[0] )

        
    '''
    @summary: 检查工程名相关信息是否规范
    '''    
    def check_name(self):        
        try:
            fullName = self.ppath.split(os.path.sep)[-1]
            tmps = fullName.split("_")
    #         project = tmps[0]  #暂时不判断
            testType = tmps[1]  #只判断是否合理，不判断是否内容正确
    #         module = tmps[2]   #暂时不判断
    #         target = tmps[3]   #暂时不判断
    #         caseid = fullName.split(target)[-1][1:]   #暂时不判断
            if testType not in ["FT","FST","SST","PST","PPT","MST","EST","Smoke"]:
                self.deal_result(ErrorCode.ErrorUnknowType,testType)
        except:
            self.deal_result(ErrorCode.ErrorUnknow,"工程命名不规范" )

            
        
    '''
    @summary: 判断Case包名与Model层命名是否一致，判断CaseID名首字母不是小写字母
    @param path: case的路径 
    '''
    def check_cases(self,path):
        for f in os.listdir(path):
            p = os.path.join(path,f)
            if os.path.isdir(p):                
                if "".join([f,".py"]) not in self.modelFiles:
                    self.deal_result(ErrorCode.ErrorCMNamed, p)
        
        for root, dirs, files in os.walk(self.casesPath):
            for file in  files:
                cp = os.path.join(path,file)
                if "__init__" not in file and file.split(".")[-1]!="pyc":
                    if not file[0].islower():
                        self.deal_result(ErrorCode.ErrorCFirstUpper, cp)  
    
    '''
    @summary: 获取model层的model文件名
    '''
    def _getModelFiles(self):
        for filename in os.listdir(self.modelPath): 
            mfpath = os.path.join(self.modelPath,filename)
            if os.path.isfile(mfpath):
                if filename not in ["testRecorder.py","__init__.py"]:
                    if filename.split(".")[-1]!="pyc":
                        self.modelFiles.append(filename)
        
    '''
    @summary: 判断Model命名首字母是否为小写
    @param path:model的路径: 
    '''
    def check_model(self,path):        
        for filename in self.modelFiles:
            rpath = os.path.join(path,filename)    
            if not filename[0].islower():
                self.deal_result(ErrorCode.ErrorMFirstUpper, rpath) 

    '''
    @summary: 判断是否存在report或者log文件夹未清除
    @param name: 文件夹名称
    @param path:文件夹目录
    '''    
    def check_directory(self,name,path):
        self._check_log_report(name,path)
        for chname in os.listdir(path):
            chpath = os.path.join(path,chname)                    
            if os.path.isdir(chpath):
                self._check_log_report(chname,chpath)
    
    def _check_log_report(self,name,path):
        if 'log' ==name:
            self.deal_result(ErrorCode.ErrorLogFolder,path)
        if 'report' ==name:
            self.deal_result(ErrorCode.ErrorReportFolder,path)

    '''
    @summary: 处理出错结果信息
    @param text:错误提示信息
    @param name:错误具体内容
    '''    
    def deal_result(self,text,name):
        self.result.append(text+"："+name)

    '''
    @summary: 结果输出       
    @note: 本地端             
    '''    
    def resultSummary(self):
        if self.result:
            for i in self.result:
                print i
        else:
            print "Code is valid!"           

    '''
    @summary: 结果输出       
    @note: 云端             
    '''    
#     def resultUploads(self):
#         {'result':{}}
#         if self.uploadsResult:
#             for i in self.uploadsResult:
#                 print i
#         else:
#             print "Code is valid!"             
            
if __name__ == '__main__':
    x = CodeCheck()
    x.step_projectNamed()
    x.step_fileChecked()
    x.resultSummary()

