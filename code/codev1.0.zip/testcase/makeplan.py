# coding=utf-8
'''
    基于cases生成测试计划
'''

import os

current_path = os.getcwd()  # 当前文件所在目录
count = 3  # 单个case测试次数


def make_plan(path):
    plan = "[tests]\n"
    if os.path.exists(path):
        for dirpath, dirname, files in os.walk(path):
            for filename in files:
                filepath = os.path.join(dirpath, filename)
                if filepath.find("__init__") > 0:
                    continue
#                 import_path = filepath[filepath.find('testcase'):-3].replace("\\", ".") + "."
                import_path = filepath[filepath.find('cases'):-3].replace("\\", ".") + "."
                f = open(filepath, 'r')
                class_name = ""
                for line in f.readlines():
                    if line.startswith('class'):
                        class_name = line[(line.find("class ") + 6): line.find('(')] + "."
                    if line.find('def test') >= 0:
                        tmp = line[line.find('test'): line.find('(')]
                        plan += import_path + class_name + tmp + "=" + str(count) + "\n"
                f.close()
    return plan


if __name__ == "__main__":

    case_path = os.path.join(current_path, 'cases')
    plan = make_plan(case_path)
    planOffline = plan.replace('[tests]', '[offline]')
    plan += planOffline
    plan += '[debug]'
    # print plan
    print 'plan',plan
    if plan.find("=") > 0:
        dest = open(current_path + "/plan", 'w')
        dest.write(plan)
        dest.close
