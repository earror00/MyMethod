# coding=utf-8

import os
from runner.application.testcasebase import TestCaseBase
from runner.common.runnerlog import RunnerLog as Logger
from testcase.model.Common import Common


'''
    :caseID 
    :前提条件  无
    :测试步骤 1.重启手机
    :预期结果 1.重启成功
'''


class CommonTest(TestCaseBase):

    @classmethod
    def setUpClass(cls):
        ''' 测试case模块初始化, 作用于整个测试周期'''
        cls.current_dir = os.path.dirname(__file__)
        cls.resource_path = os.path.join(os.path.dirname(os.path.dirname(cls.current_dir)),'resources')
        super(CommonTest, cls).setUpClass()
        try:
            '''模块初始化'''
            
        except Exception, e:
            Logger.error('CommonTest module init failure: ' + str(e))
            
            
    @classmethod
    def tearDownClass(cls):
        super(CommonTest, cls).tearDownClass()
        try:
            '''模块资源释放'''
            
        except Exception, e:
            Logger.error('CommonTest module clear resource failure: ' + str(e))
    
    def setUp(self):
        ''' 测试case初始化，作用于单个测试方法'''
        super(CommonTest, self).setUp()
        self.Common =  Common(self)  # 初始化model

    def tearDown(self):
        super(CommonTest, self).tearDown()

    def test_Reboot(self):
        
        self.Common.rebootDevice()
        
        pass
