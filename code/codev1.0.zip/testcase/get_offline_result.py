# coding=utf-8
"""
Created on 2018年05月15日

@author: lxs
"""

from easyuiautomator.driver.executor.adb_offline import AdbOffline

def main():
    _adb = AdbOffline()
    _adb.pullTestResult();

if __name__ == '__main__':
    main()